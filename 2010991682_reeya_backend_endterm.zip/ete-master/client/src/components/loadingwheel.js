const Wheel = () => {
    return(
        <div class="wrapper">
            <span></span>
        </div>
    )
}

export default Wheel;