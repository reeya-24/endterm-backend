import "./main.scss";
import "./footer.scss";
import "./loadingwheel.scss";
import Layout from "./components/layout";

function App() {
  return (
    <Layout/>
  );
}

export default App;
